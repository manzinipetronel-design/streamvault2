import Link from 'next/link';
import MovieRow from '@/components/MovieRow';
import HeroCarousel from '@/components/HeroCarousel';
import HeaderAvatar from '@/components/HeaderAvatar';
import { getVisitorCountry, countryName } from '@/lib/geo';

const mockHero = {
  id: 3,
  title: 'SYNAPSE OVERRIDE',
  overview:
    'In a hyper-connected neo-metropolis, a detective who can replay digitized memories discovers a sequence that shouldn’t exist.',
  backdrop_path: '/placeholder-hero',
  poster_path: '',
  vote_average: 8.7,
  release_date: '2026-04-10',
};

const mockSeries = [
  {
    id: 201,
    name: 'Cyber Horizon',
    title: 'Cyber Horizon',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 8.5,
    first_air_date: '2026-01-01',
  },
  {
    id: 202,
    name: 'Neon District',
    title: 'Neon District',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 8.1,
    first_air_date: '2025-01-01',
  },
  {
    id: 203,
    name: 'The Binary Path',
    title: 'The Binary Path',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 8.3,
    first_air_date: '2026-01-01',
  },
];

async function fetchSeries(genreId?: number, endpoint?: string) {
  const apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY || '16c821fbbcf070c4961e6a90863619a8';
  const baseUrl = 'https://api.themoviedb.org/3';
  if (!apiKey) return [];
  const url = genreId
    ? `${baseUrl}/discover/tv?api_key=${apiKey}&with_genres=${genreId}&sort_by=popularity.desc&include_adult=false`
    : `${baseUrl}${endpoint}?api_key=${apiKey}`;
  try {
    const res = await fetch(url, {
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
  } catch {
    return [];
  }
}

// TMDB has no real "trending in country X" chart — that's proprietary
// viewership data only individual streaming services (Netflix, etc.) have.
// What we CAN show honestly: shows actually available to stream in the
// visitor's region, ranked by TMDB's popularity score. watch_region +
// with_watch_monetization_types restricts results to titles with a real
// streaming/rental option there, so the row isn't just "popular somewhere".
async function fetchPopularInRegion(countryCode: string) {
  const apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY || '16c821fbbcf070c4961e6a90863619a8';
  const baseUrl = 'https://api.themoviedb.org/3';
  if (!apiKey) return [];
  const url =
    `${baseUrl}/discover/tv?api_key=${apiKey}&watch_region=${countryCode}` +
    `&with_watch_monetization_types=flatrate|free|ads&sort_by=popularity.desc&include_adult=false`;
  try {
    const res = await fetch(url, {
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
  } catch {
    return [];
  }
}

export default async function SeriesPage() {
  const countryCode = await getVisitorCountry();

  let trending: any[] = [];
  let action: any[] = [];
  let scifi: any[] = [];
  let comedy: any[] = [];
  let popularInRegion: any[] = [];
  try {
    [trending, action, scifi, comedy, popularInRegion] = await Promise.all([
      fetchSeries(undefined, '/trending/tv/week'),
      fetchSeries(10759),
      fetchSeries(10765),
      fetchSeries(35),
      fetchPopularInRegion(countryCode),
    ]);
  } catch {}

  const trendingItems = trending.length > 0 ? trending : mockSeries;
  const actionItems =
    action.length > 0 ? action : mockSeries.map((m) => ({ ...m, id: m.id + 100 }));
  const scifiItems =
    scifi.length > 0 ? scifi : mockSeries.map((m) => ({ ...m, id: m.id + 200 }));
  const comedyItems =
    comedy.length > 0 ? comedy : mockSeries.map((m) => ({ ...m, id: m.id + 300 }));
  const popularInRegionItems = popularInRegion.length > 0 ? popularInRegion : trendingItems;
  const popularInRegionIsMock = popularInRegion.length === 0 && trendingItems === mockSeries;
  const regionLabel = countryName(countryCode);

  return (
    <div className="page-enter min-h-screen bg-void text-foreground overflow-x-hidden font-sans antialiased selection:bg-violet selection:text-white pb-20">
      <header className="fixed top-0 left-0 w-full z-50 bg-gradient-to-b from-black/90 via-black/40 to-transparent px-6 md:px-12 py-5 flex items-center justify-between backdrop-blur-[2px]">
        <div className="flex items-center gap-10">
          <Link
            href="/"
            className="font-display font-extrabold text-lg tracking-tight bg-gradient-to-r from-violet-light to-magenta bg-clip-text text-transparent"
          >
            STREAMVAULT
          </Link>
          <nav className="desktop-nav hidden md:flex items-center gap-6 text-[13px] text-muted font-medium">
            <Link href="/" className="hover:text-foreground transition duration-200">
              Home
            </Link>
            <Link href="/series" className="text-foreground">
              Series
            </Link>
            <Link href="/movies" className="hover:text-foreground transition duration-200">
              Movies
            </Link>
            <Link href="/browse" className="hover:text-foreground transition duration-200">
              Browse
            </Link>
            <Link href="/new" className="hover:text-foreground transition duration-200">
              New & Popular
            </Link>
            <Link href="/lists" className="hover:text-foreground transition duration-200">
              Watchlist
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-6">
          <Link
            href="/search"
            className="text-muted hover:text-foreground text-sm font-medium transition cursor-pointer"
          >
            Search
          </Link>
          <HeaderAvatar />
        </div>
      </header>

      <HeroCarousel movies={trending.slice(0, 5)} mockHero={mockHero} />

      <div className="relative z-20 pb-32 -mt-8 flex flex-col">
        <MovieRow
          title={`Popular in ${regionLabel}`}
          items={popularInRegionItems}
          isMock={popularInRegionIsMock}
          mediaType="tv"
          showRank
        />
        <MovieRow title="Popular TV Shows" items={trendingItems} isMock={trendingItems === mockSeries} mediaType="tv" />
        <MovieRow
          title="Action & Adventure Series"
          items={actionItems}
          isMock={actionItems.length > 0 && actionItems[0].id > 100 && actionItems[0].id < 210}
          mediaType="tv"
        />
        <MovieRow
          title="Sci-Fi & Fantasy Series"
          items={scifiItems}
          isMock={scifiItems.length > 0 && scifiItems[0].id > 200 && scifiItems[0].id < 310}
          mediaType="tv"
        />
        <MovieRow
          title="Comedy Series"
          items={comedyItems}
          isMock={comedyItems.length > 0 && comedyItems[0].id > 300 && comedyItems[0].id < 410}
          mediaType="tv"
        />
      </div>
    </div>
  );
}
