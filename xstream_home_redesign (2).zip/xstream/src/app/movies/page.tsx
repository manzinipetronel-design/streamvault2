import Link from 'next/link';
import MovieRow from '@/components/MovieRow';
import HeroCarousel from '@/components/HeroCarousel';
import HeaderAvatar from '@/components/HeaderAvatar';

const mockHero = {
  id: 2,
  title: 'INTERSTELLAR ODYSSEY',
  overview:
    'A venture across the unmapped expanse beyond the outer ring to salvage a derelict deep-space sanctuary before an anomalous solar flare consumes it.',
  backdrop_path: '/placeholder-hero',
  poster_path: '',
  vote_average: 8.9,
  release_date: '2026-06-20',
};

const mockMovies = [
  {
    id: 101,
    title: 'Nebula Matrix',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 8.4,
    release_date: '2026-01-01',
  },
  {
    id: 102,
    title: 'Shadow Protocol',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 7.9,
    release_date: '2025-01-01',
  },
  {
    id: 103,
    title: 'The Whispering',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1593118247619-e2d6f056869e?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 8.2,
    release_date: '2026-01-01',
  },
  {
    id: 104,
    title: 'Eldoria Dominion',
    overview: '',
    backdrop_path: '',
    poster_path:
      'https://images.unsplash.com/photo-1605806616949-1e87b487cb2a?auto=format&fit=crop&q=80&w=600&h=900',
    vote_average: 7.5,
    release_date: '2025-01-01',
  },
];

async function fetchMovies(genreId?: number, endpoint?: string) {
  const apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY || '16c821fbbcf070c4961e6a90863619a8';
  const baseUrl = 'https://api.themoviedb.org/3';
  if (!apiKey) return [];
  const url = genreId
    ? `${baseUrl}/discover/movie?api_key=${apiKey}&with_genres=${genreId}&sort_by=popularity.desc&include_adult=false`
    : `${baseUrl}${endpoint}?api_key=${apiKey}`;
  try {
    const res = await fetch(url, {
      next: { revalidate: 3600 },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.results || [];
  } catch {
    return [];
  }
}

export default async function MoviesPage() {
  let trending: any[] = [];
  let action: any[] = [];
  let scifi: any[] = [];
  let comedy: any[] = [];
  try {
    [trending, action, scifi, comedy] = await Promise.all([
      fetchMovies(undefined, '/trending/movie/week'),
      fetchMovies(28),
      fetchMovies(878),
      fetchMovies(35),
    ]);
  } catch {}

  const trendingItems = trending.length > 0 ? trending : mockMovies;
  const actionItems =
    action.length > 0 ? action : mockMovies.map((m) => ({ ...m, id: m.id + 100 }));
  const scifiItems =
    scifi.length > 0 ? scifi : mockMovies.map((m) => ({ ...m, id: m.id + 200 }));
  const comedyItems =
    comedy.length > 0 ? comedy : mockMovies.map((m) => ({ ...m, id: m.id + 300 }));

  return (
    <div className="page-enter min-h-screen bg-void text-foreground overflow-x-hidden font-sans antialiased selection:bg-violet selection:text-white pb-20">
      <header className="fixed top-0 left-0 w-full z-50 bg-gradient-to-b from-black/90 via-black/40 to-transparent px-6 md:px-12 py-5 flex items-center justify-between backdrop-blur-[2px]">
        <div className="flex items-center gap-10">
          <Link
            href="/"
            className="font-display font-extrabold text-lg tracking-tight bg-gradient-to-r from-violet-light to-magenta bg-clip-text text-transparent"
          >
            STREAMVAULT
          </Link>
          <nav className="desktop-nav hidden md:flex items-center gap-6 text-[13px] text-muted font-medium">
            <Link href="/" className="hover:text-foreground transition duration-200">
              Home
            </Link>
            <Link href="/series" className="hover:text-foreground transition duration-200">
              Series
            </Link>
            <Link href="/movies" className="text-foreground">
              Movies
            </Link>
            <Link href="/browse" className="hover:text-foreground transition duration-200">
              Browse
            </Link>
            <Link href="/new" className="hover:text-foreground transition duration-200">
              New & Popular
            </Link>
            <Link href="/lists" className="hover:text-foreground transition duration-200">
              Watchlist
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-6">
          <Link
            href="/search"
            className="text-muted hover:text-foreground text-sm font-medium transition cursor-pointer"
          >
            Search
          </Link>
          <HeaderAvatar />
        </div>
      </header>

      <HeroCarousel movies={trending.slice(0, 5)} mockHero={mockHero} />

      <div className="relative z-20 pb-32 -mt-8 flex flex-col">
        <MovieRow title="Popular Movies" items={trendingItems} isMock={trendingItems === mockMovies} mediaType="movie" />
        <MovieRow
          title="Action & Adventure"
          items={actionItems}
          isMock={actionItems.length > 0 && actionItems[0].id > 100 && actionItems[0].id < 210}
          mediaType="movie"
        />
        <MovieRow
          title="Sci-Fi & Fantasy"
          items={scifiItems}
          isMock={scifiItems.length > 0 && scifiItems[0].id > 200 && scifiItems[0].id < 310}
          mediaType="movie"
        />
        <MovieRow
          title="Comedy Hits"
          items={comedyItems}
          isMock={comedyItems.length > 0 && comedyItems[0].id > 300 && comedyItems[0].id < 410}
          mediaType="movie"
        />
      </div>
    </div>
  );
}
