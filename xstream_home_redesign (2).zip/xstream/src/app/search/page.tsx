'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import HeaderAvatar from '@/components/HeaderAvatar';
import { tmdbService } from '@/lib/services/tmdbService';

type SearchItem = {
  id: number;
  title: string;
  name?: string;
  mediaType?: string;
  type?: string;
  media_type?: 'movie' | 'tv';
  poster_path?: string | null;
  backdrop_path?: string | null;
  vote_average?: number;
  release_date?: string;
  first_air_date?: string;
  air_date?: string;
};

const posterUrl = (path?: string | null, size: 'w342' | 'w500' | 'original' = 'w342') => {
  if (!path) return '/assets/images/no_image.png';
  return `https://image.tmdb.org/t/p/${size}${path}`;
};

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'movie', label: 'Movies' },
  { key: 'tv', label: 'Series' },
] as const;

export default function BrowseSearchPage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [movies, setMovies] = useState<SearchItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'movie' | 'tv'>('all');
  const [isRedirecting, setIsRedirecting] = useState<string | null>(null);

  useEffect(() => {
    async function loadTrending() {
      if (searchQuery.trim() !== '') return;

      setLoading(true);
      try {
        const data = await tmdbService.getTrending('all', 'day');
        const validMedia = (data.results || []).filter((item: SearchItem) => item.poster_path);
        setMovies(validMedia);
      } catch (error) {
        console.error('Failed to load catalog:', error);
      } finally {
        setLoading(false);
      }
    }

    loadTrending();
  }, [searchQuery]);

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const data = await tmdbService.searchMulti(searchQuery);
      const searchResults = (data.results || []).filter(
        (item: SearchItem) =>
          (item.media_type === 'movie' || item.media_type === 'tv') && item.poster_path
      );
      setMovies(searchResults);
    } catch (error) {
      console.error('Search query fetch failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredMovies = movies.filter((item) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'movie') return item.media_type === 'movie' || !item.media_type;
    if (activeFilter === 'tv') return item.media_type === 'tv';
    return true;
  });

  const handleCardClick = (mediaType: string, id: string) => {
    if (isRedirecting) return;
    setIsRedirecting(id);
    router.push(`/media/${mediaType}/${id}`);
  };

  return (
    <div className="page-enter min-h-screen bg-void text-foreground font-sans antialiased selection:bg-violet selection:text-white pb-24">
      {/* Nav — same treatment as every other page */}
      <header className="fixed top-0 left-0 w-full z-50 bg-gradient-to-b from-black/90 via-black/40 to-transparent px-6 md:px-12 py-5 flex items-center justify-between backdrop-blur-[2px]">
        <div className="flex items-center gap-10">
          <Link
            href="/"
            className="font-display font-extrabold text-lg tracking-tight bg-gradient-to-r from-violet-light to-magenta bg-clip-text text-transparent"
          >
            STREAMVAULT
          </Link>
          <nav className="desktop-nav hidden md:flex items-center gap-6 text-[13px] text-muted font-medium">
            <Link href="/" className="hover:text-foreground transition duration-200">
              Home
            </Link>
            <Link href="/series" className="hover:text-foreground transition duration-200">
              Series
            </Link>
            <Link href="/movies" className="hover:text-foreground transition duration-200">
              Movies
            </Link>
            <Link href="/browse" className="hover:text-foreground transition duration-200">
              Browse
            </Link>
            <Link href="/lists" className="hover:text-foreground transition duration-200">
              Watchlist
            </Link>
          </nav>
        </div>
        <HeaderAvatar />
      </header>

      <main className="pt-28 px-6 md:px-12 max-w-7xl mx-auto">
        <h1 className="font-display text-3xl md:text-[38px] font-extrabold leading-tight tracking-tight mb-8">
          Search
        </h1>

        <form onSubmit={handleSearchSubmit} className="flex gap-3 mb-8 max-w-2xl">
          <div className="relative flex-1">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-muted"
            >
              <circle cx="11" cy="11" r="7" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search movies, shows, people..."
              className="w-full bg-void-2 border border-glass-border rounded-xl pl-11 pr-4 py-3 text-sm text-foreground placeholder-muted focus:outline-none focus:border-violet transition-colors"
            />
          </div>
          <button
            type="submit"
            className="px-6 py-3 rounded-xl text-void font-display font-semibold text-[13.5px] hover:opacity-90 active:scale-95 transition-all duration-150"
            style={{ background: 'linear-gradient(180deg, #ffffff, #e8e6ea)' }}
          >
            Search
          </button>
        </form>

        <div className="flex items-center justify-between mb-7 flex-wrap gap-3">
          <div className="flex gap-2">
            {FILTERS.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setActiveFilter(key)}
                className={`px-3.5 py-1.5 rounded-lg font-medium text-xs transition-all cursor-pointer ${
                  activeFilter === key
                    ? 'bg-foreground text-void'
                    : 'bg-void-2 hover:bg-void-3 border border-glass-border text-muted hover:text-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <span className="text-[12.5px] text-muted">{filteredMovies.length} results</span>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="aspect-[2/3] rounded-[10px] bg-void-2 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="spotlight-scope grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {filteredMovies.map((item) => {
              const title = item.title || item.name || 'Untitled';
              const releaseDate = item.release_date || item.first_air_date || '';
              const year = releaseDate ? releaseDate.split('-')[0] : '';
              const rating = item.vote_average || 0;
              const explicitType = item.mediaType || item.media_type;
              let safeType = explicitType?.toLowerCase() || 'movie';

              if (!explicitType && item.type?.toLowerCase().includes('tv')) {
                safeType = 'tv';
              } else if (!explicitType && (item.first_air_date || item.air_date)) {
                safeType = 'tv';
              }

              if (safeType !== 'tv' && safeType !== 'movie') {
                safeType = 'movie';
              }

              const isThisCardLoading = isRedirecting === item.id.toString();

              return (
                <button
                  key={item.id}
                  onClick={() => handleCardClick(safeType, item.id.toString())}
                  className="group relative text-left rounded-[10px] overflow-hidden cursor-pointer"
                >
                  <div className="relative aspect-[2/3] w-full overflow-hidden bg-void-2">
                    <span className="absolute top-2 left-2 z-10 text-[9px] font-display font-semibold uppercase tracking-wide text-foreground/80 bg-black/50 backdrop-blur-sm px-1.5 py-0.5 rounded">
                      {safeType === 'tv' ? 'Series' : 'Movie'}
                    </span>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={posterUrl(item.poster_path)}
                      alt={title}
                      loading="lazy"
                      className={`quiet-media w-full h-full object-cover ${
                        isThisCardLoading ? 'blur-[2px]' : 'group-hover:scale-[1.045]'
                      }`}
                    />
                    {isThisCardLoading && (
                      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-void/70 backdrop-blur-sm">
                        <div className="w-7 h-7 rounded-full border-2 border-t-transparent border-violet animate-spin" />
                        <span className="text-[10px] font-medium tracking-wider uppercase text-muted">
                          Loading...
                        </span>
                      </div>
                    )}
                    <div className="absolute inset-0 flex flex-col justify-end p-3 bg-gradient-to-t from-void via-void/15 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <p className="font-display font-semibold text-[13px] leading-tight mb-1 line-clamp-2">
                        {title}
                      </p>
                      <div className="flex items-center gap-2 text-[11px] text-muted">
                        {rating > 0 && (
                          <span className="flex items-center gap-[3px] text-gold font-semibold">
                            <svg viewBox="0 0 24 24" className="w-[9px] h-[9px] fill-gold">
                              <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.9-6.2 3.9 1.6-7L2 9.2l7.1-.6z" />
                            </svg>
                            {rating.toFixed(1)}
                          </span>
                        )}
                        <span>{year}</span>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {!loading && filteredMovies.length === 0 && (
          <p className="text-muted text-sm py-20 text-center">
            No matches found — try widening your search terms.
          </p>
        )}
      </main>
    </div>
  );
}
